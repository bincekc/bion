﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    class Order3
    {
        public int Order_id { get; set; }
        public string item_name { get; set; }
        public DateTime Orderdate { get; set; }
        public int Quantity { get; set; }

        public Order3(int id, string Name, DateTime orderdate, int quantity)
        {
            Order_id = id;
            item_name = Name;
            Orderdate = orderdate;
            Quantity = quantity;

        }
    }
    internal class qn7
    {
        static void Main()
        {
            List<Order3> orders = new List<Order3>()
            {
                new Order3(1,"ball",DateTime.Parse("2/23/2000"),10),
                new Order3 (2,"shoes",DateTime.Parse("6/23/2000"),20),
                new Order3 (3,"box",DateTime.Parse("7/23/2000"),30),
                new Order3 (4,"bat",DateTime.Parse("1/23/2000"),0)

            };



             DateTime today = DateTime.Today;

            bool anyOrdersBeforeJanuary = orders.Any(order => order.Orderdate < new DateTime(today.Year, 1, 1));

            if (anyOrdersBeforeJanuary)
            {
                Console.WriteLine("Orders placed before January ");
            }
            else
            {
                Console.WriteLine("No orders placed before January ");
            }

                    var itemNameWithMaxQuantity = orders
            .GroupBy(order => order.item_name)
            .Select(group => new
            {
                ItemName = group.Key,
                MaxQuantity = group.Max(order => order.Quantity)
            })
            .OrderByDescending(item => item.MaxQuantity)
            .FirstOrDefault()?.ItemName;

                    Console.WriteLine($"Item ordered in largest quantity: {itemNameWithMaxQuantity}");
        }
    }
}