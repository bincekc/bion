﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    class Orders2
    {
        public int OrderId { get; set; }
        public string ItemName { get; set; }
        public DateTime OrderDate { get; set; }
        public int Quantity { get; set; }
    }

    class Item_1
    {
        public string ItemName { get; set; }
        public double Price { get; set; }
    }

    internal class qn6
    {
        public static void Main()
        {
            List<Orders2> orders = new List<Orders2>
            {
                new Orders2 { OrderId = 111, ItemName = "ball", OrderDate = new DateTime(2024, 1, 5), Quantity = 2 },
                 new Orders2 { OrderId = 2222, ItemName = "pencil", OrderDate = new DateTime(2024, 1, 8), Quantity = 6 },
                new Orders2 { OrderId = 3122, ItemName = "scale", OrderDate = new DateTime(2024, 2, 12), Quantity = 5 },
            };

            List<Item_1> items = new List<Item_1>
            {
                new Item_1 { ItemName = "bat", Price = 30.34},
                new Item_1 { ItemName = "ball", Price = 75.23 },

            };

            var query = from order in orders
                              join item in items on order.ItemName equals item.ItemName
                              group new { order.OrderId, order.ItemName, order.OrderDate, TotalPrice = order.Quantity * item.Price }
                              by new { Month = order.OrderDate.Month, order.OrderId, order.ItemName, order.OrderDate }
                              into groupedOrders
                              orderby groupedOrders.Key.OrderDate descending
                              select new
                              {
                                  groupedOrders.Key.OrderId,
                                  groupedOrders.Key.ItemName,
                                  groupedOrders.Key.OrderDate,
                                  TotalPrice = groupedOrders.Sum(o => o.TotalPrice)
                              };

            // Displaying the result
            foreach (var result in query)
            {
                Console.WriteLine($"Order ID: {result.OrderId}, Item Name: {result.ItemName}, Order Date: {result.OrderDate}, Total Price: {result.TotalPrice}");
            }
        }
    }
}