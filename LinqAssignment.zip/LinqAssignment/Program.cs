﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    internal class Program
    {
      
      static void Main(string[] args)
        {
            int[] num = { 7, 8,6,5,12,54,77,4,15,22 };

            var result = from k in num
                         let j = k * k * k
                         where j > 100 && j < 1000
                         select j;
            foreach (var i in result)
            {
                Console.WriteLine(i);
            }
        }
    }
}