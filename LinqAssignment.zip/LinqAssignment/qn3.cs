﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    class Order
    {
        public int Order_id { get; set; }
        public string item_name { get; set; }
        public DateTime Orderdate { get; set; }
        public int Quantity { get; set; }

        public Order(int id, string Name, DateTime orderdate, int quantity)
        {
            Order_id = id;
            item_name = Name;
            Orderdate = orderdate;
            Quantity = quantity;

        }
    }
    internal class qn3
    {
        static void Main(string[] args)
        {
            List<Order> orders = new List<Order>()
            {
                new Order (1,"bat",DateTime.Parse("2/23/2000"),5),
                new Order (2,"chair",DateTime.Parse("6/23/2000"),25),
                new Order (3,"shoes",DateTime.Parse("7/23/2000"),13),
                new Order(4, "desk", DateTime.Parse("9/24/2000"), 36)

            };
            var orderedByDateAndQuantity = orders.OrderByDescending(o => o.Orderdate).ThenByDescending(o => o.Quantity);
            foreach (var order in orderedByDateAndQuantity)
            {
                Console.WriteLine($"Orderid:{order.Order_id}, item_name:{order.item_name},Orderdate:{order.Orderdate},Quantity:{order.Quantity}");
            }

        }
    }
}