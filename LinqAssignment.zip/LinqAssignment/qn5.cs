﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    class Orders1
    {
        public int OrderId { get; set; }
        public string ItemName { get; set; }
        public DateTime OrderDate { get; set; }
        public int Quantity { get; set; }
    }

    class Item
    {
        public string ItemName { get; set; }
        public double Price { get; set; }
    }
    internal class qn5
    {
        static void Main()
        {
            List<Orders1> orders = new List<Orders1>
        {
            new Orders1 { OrderId = 111, ItemName = "ball", OrderDate = new DateTime(2024, 1, 5), Quantity = 2 },
            new Orders1 { OrderId = 2222, ItemName = "bat", OrderDate = new DateTime(2024, 1, 8), Quantity = 6 },
            new Orders1 { OrderId = 3122, ItemName = "stump", OrderDate = new DateTime(2024, 2, 12), Quantity = 5 },

        };

            List<Item> items = new List<Item>
        {
            new Item { ItemName = "ball", Price = 10.50 },
            new Item { ItemName = "bat", Price = 20.75 },

        };

            // LINQ query to get the desired result
            var query = from order in orders
                              join item in items on order.ItemName equals item.ItemName
                              group new { order.OrderId, order.ItemName, order.OrderDate, TotalPrice = order.Quantity * item.Price }
                              by new { Month = order.OrderDate.Month, order.OrderId, order.ItemName, order.OrderDate }
                              into groupedOrders
                              orderby groupedOrders.Key.OrderDate descending
                              select new
                              {
                                  groupedOrders.Key.OrderId,
                                  groupedOrders.Key.ItemName,
                                  groupedOrders.Key.OrderDate,
                                  TotalPrice = groupedOrders.Sum(o => o.TotalPrice)
                              };

            // Displaying the result
            foreach (var result in query)
            {
                Console.WriteLine($"Order ID: {result.OrderId}, Item Name: {result.ItemName}, Order Date: {result.OrderDate}, Total Price: {result.TotalPrice}");
            }
        }

    }
}